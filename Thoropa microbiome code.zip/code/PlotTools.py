
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as pt
import networkx as nx

import numpy as np
import math


###### GLOBAL PARAMS

# For differentiating categories:
# Color scale
group_cmap= 'gist_rainbow'

# Hatch patterns
patterns = ['',   '+', '/',  '-',  '*', '\\', 'O','x' ]

# Font params
labelfont = {#'font-family':'serif', 
             'fontsize':18}
cbtickfont = {'labelsize':18}

# Style of significance markers
p_threshold = [ math.log(20,10), 2 ]
p_styles = [
    {'marker':'.', 'c':'k',
    'linestyle':'', 'markersize':10},
    {'marker':'*', 'c':'w',
    'linestyle':'', 'markersize':10}, ]


######## Opening and closing figures

def FigAndAx(figsize=(8,8), axRect=(0.1,0.1,0.8,0.8) ):
    # Get a figure and axes

    fig = pt.figure( figsize=figsize)
    ax = fig.add_axes( axRect )

    return fig, ax

def SaveAndClose(fig, plot_name, 
                 dpi=300, bbox_inches='tight', **params):
    """ Save the figure and close it. """
    fig.savefig(plot_name, dpi=dpi, bbox_inches=bbox_inches, **params )
    pt.close(fig)



###### Legend

def Legend( **params ):
    """ Add a legend to the figure """
    if not 'bbox_to_anchor' in params:
        params['bbox_to_anchor'] = (1,0,0.3,1.01)
    if not 'loc' in params:
        params['loc'] = 'upper left'
    if not 'scatterpoints' in params:
        params['scatterpoints'] = 1
    if not 'fontsize' in params:
        params['fontsize' ] = labelfont['fontsize']

    if 'fig' in params:
        fig = params.pop('fig')
        return fig.legend(**params)

    return pt.legend( **params  ) 
    
    
######## Nice colors and hatches for groups of things

def GetColors(num_groups, alpha=1.0):
    my_cmap=group_cmap
    norm = mpl.colors.Normalize(
        vmin=0, vmax=num_groups-0.5)
    scalarMap = mpl.cm.ScalarMappable(
        cmap=my_cmap,
        norm=norm)
    colors = np.array(
        [ list(scalarMap.to_rgba(x)) for x in range(num_groups)
        ] )
    colors[:, -1] = alpha
    return colors

def GetHatches(num_groups):
    return [ patterns[ x % len(patterns) ]
             for x in range(num_groups) ]

def GetFillStyles(labels, pastel=0.7, alpha=1.):
    "List of dictionaries of fill styles for our bar charts "
    N = len(labels)
    colors = GetColors(N, alpha=alpha)

    for ii in range(N):
        colors[ii,:3] = list( 
            np.array( colors[ii][:3]) * pastel + 1.-pastel )
    

    return [
        {  'facecolor':c,  
           'hatch':h, 'label':L, 
           'edgecolor':'k' }
        for c,h,L in zip( colors, GetHatches(N), labels) ]
    


####### Plotting matrix and colors

def MatrixAndColorbar(ax, M, do_colorbar=True, tight_axes=True, **params):
    """ Plot nice matrix and return colobar object. """
    # Defaults
    if not 'interpolation' in params:
        params['interpolation'] = 'nearest'

    if not 'origin' in params:
        params['origin'] = 'lower'

    if not 'cmap' in params:
        params['cmap'] = 'binary'

    if not 'aspect' in params:
        params['aspect'] = 'auto'

    if not 'extent' in params:
        params['extent'] = (0, M.shape[1], 0, M.shape[0])

    # Draw the matrix
    colors = ax.imshow(M, **params)
    # If want axes to only contain this imace, rescale
    if tight_axes:
        xmin, xmax, ymin, ymax = params['extent']
        ax.set_xlim( xmin,xmax)
        ax.set_ylim( ymin, ymax)

    # Make and return the colorbar
    if do_colorbar:
        return pt.colorbar(colors)
        
        
        
######### Network plotting

def PrettyDraw(dot_styles, raw_sizes, W,
               fixed_pos=None,
               dpi=300, figsize=(12,12), nrows=12,
               pos_iters=5000,
               loop_min=0.001, loop_max=10.0,
               width_min=0.0025, width_max=.01,
               scale=1.0, pad=0.075, max_size=4000.,
               ringsize=3.25,
               min_size=400.,
               alpha_pow=1.0, alpha_norm=True, alpha_min=0.1,
               spring_pow=1., spring_max=4.0, spring_min=0.1 ):
    """ Do a PRETTY drawing of a weighted graph """

    print W.shape

    # Fig length in pixels
    figL = float(figsize[0]) * float( dpi )
    size_to_R =  ( scale*(1.+pad*2.) ) / figL * ringsize

    N = len(raw_sizes)


    directed = ( max( abs( (W-W.T).ravel() ) ) > 10E-6 )


    # If finding new pos:
    isolated = np.array([ 
        xi for xi, x in enumerate(W + W.T)
        if sum( x ) <= x[xi] ])
        
    # Any nodes with edges:
    connected = np.array([ xi for xi in range(N)
                            if not xi in isolated])

    # Positions:
    pos = fixed_pos
    if pos is None:
        
        # Any isolated nodes just line up like legend
        pos = dict()
        if len(isolated) > 0:
            ncols = len(isolated) / nrows + 1
            ys = np.linspace(0, scale, nrows)[::-1]
            xs = -2.* scale /float(nrows) * np.arange(1., 1. + ncols)[::-1]
            for ii, v in enumerate(isolated):
                pos[v] = (xs[ ii/len(ys) ], ys[ ii % len(ys) ] )
        
        
        if len(connected) > 0:
            # Spring layout of non-isolated edges
            spring_weights = np.array(W)[connected][:, connected]
            spring_weights = spring_weights**spring_pow
        
            for ii in range( len(spring_weights) ):
                spring_weights[ii,ii] = 0
        
            spring_weights = ( spring_weights * (spring_max-spring_min) 
                                / max(spring_weights.ravel()) + spring_min )

            # Make a graph
            if not directed:
                G = nx.from_numpy_matrix( spring_weights )
            else:
                G = nx.DiGraph()
                G.add_nodes_from(range(N))
                for ii, row in enumerate(spring_weights):
                    for jj, w in enumerate(row):
                        if w > 0:
                            G.add_edge(ii,jj)
                            G[ii][jj]['weight'] = w

            
            # Initial positions for connected
            con_pos= nx.circular_layout(G, scale=scale)
            # Spring rearrange
            con_pos = nx.spring_layout(G, pos=con_pos,
                                iterations=pos_iters, weight='weight', 
                                scale=scale)
    
            # Isolated and connected positions together
            for ci, c in enumerate(connected):
                pos[c] = con_pos[ci]
                
    
    # xs, ys
    xs, ys = map(np.array, zip(*[pos[ii] for ii in range(N)]) )
    # Rescale ys of isolated and connected separately
    if len(isolated) > 0:
        ys[ isolated ] = ys[isolated]-min(ys[isolated])
        if max(ys[isolated]) == 0:
	        ys[isolated] = scale/2.
        else:
            ys[ isolated ] = ys[ isolated ]/max(ys[ isolated ]) * scale
    
    # Connected
    if len(connected) > 0:
        ys[ connected ] = ys[connected]-min(ys[connected])
        if max(ys[connected]) == 0:
            ys[connected] = scale/2.
        else:
            ys[ connected ] = ys[ connected ]/max(ys[ connected ]) * scale
    
        # Rescale connected xs, then all xs into box [0,scale]^2
        xs[connected] = xs[connected]-min(xs[connected])
        if max(xs[connected]) == 0:
    	    xs[connected] = scale/2.
        else:
   	     xs[connected] = xs[connected]/max(xs[connected]) * scale
    
    xs = xs-min(xs)
    if max(xs) == 0:
        xs[:] = scale/2.
    else:
        xs = xs/max(xs) * scale



    # Rescale sizes
    sizes=np.array(raw_sizes, dtype=float)
    sizes = min_size + (max_size-min_size) * sizes/max(sizes)
    R = max(sizes)**0.5 * size_to_R # All at equal radius

    #sizes[sizes<min_size] = min_size

    # Arrow widths
    widths = np.array(W) 
    loop_widths = np.diag(W)
    widths += - np.diag(loop_widths)

    if max(widths.ravel()) > 0:    
        widths = widths / max( widths.ravel() ) * (width_max - width_min)
        widths[widths>0] +=  width_min 

    if max(loop_widths) > 0:
	loop_widths = loop_widths / max(loop_widths) * (
            loop_max - loop_min)
        loop_widths[loop_widths>0] += loop_min
    

    alphas = np.array(W)**alpha_pow
    if alpha_norm and max(alphas.ravel()) > 0:
        alphas = alphas/max(alphas.ravel())
    alphas[alphas<alpha_min] = alpha_min

    # Plot
    fig = pt.figure( figsize=figsize )
    ax = fig.add_axes( (0,0,1,1) )
    ax.axis('off')
    
    for x,y,style,size in zip(xs,ys,dot_styles,sizes):
        ax.scatter(x,y, s=size, zorder=1,  **style)

    ax.set_xlim(-pad*scale, (1.+ pad)*scale)
    ax.set_ylim(-pad*scale, (1.+ pad)*scale)

    # Arrows
    for ii in range(N):

        # Arrow start
        x,y = xs[ii], ys[ii]
        
        # Style
        style = {'zorder':0}
        
        # Color by weight
        style['linewidth'] = loop_widths[ii] 
        style['color'] = [0,0,0, alphas[ii,ii] ]
        
        angles = np.linspace(0, 2.0 * math.pi, 100)
        
        ax.plot(
            x + R* np.array([math.cos(a) for a in angles]),
            y + R* np.array([math.sin(a) for a in angles]),
            **style)

        j_range = range(N)
        if not directed:
            j_range = range(ii)

        for jj in j_range:
            if not ii==jj and W[ii][jj] > 0:
                # Arrow change
                dx = xs[jj]-xs[ii]
                dy = ys[jj]-ys[ii]

                # Style
                style = {'zorder':0 }

                # Color by weight
                style['color'] = [0,0,0, alphas[ii,jj] ]


                # Length
                L = ( dx**2 + dy**2 ) **0.5

                if (directed):
                    style['width'] = widths[ii,jj] 
                    style[ 'head_length' ] = min(style['width'] * 4.0,
                                                 L/4.0)
                    style[ 'head_width' ] = style[ 'head_length' ]  
                    
                        
                    # New length - don't go to center of to group, go to edge
                    total_L = (L - sizes[jj]**0.5 * size_to_R ) 
                    shaft_L = total_L - style[ 'head_length' ]
                    arrow_scale = shaft_L / L


                    ax.arrow (  x, y, # From
                            arrow_scale*dx, arrow_scale*dy, # Change
                            **style )
                
                    
                else:
                    style['linewidth'] = widths[ii,jj] *loop_max / width_max
                    
                    #style[ 'head_length' ] = 0
                    #style[ 'head_width' ] = 0

                        
                    # New length -don't go to center of to group, go to edge
                    arrow_scale=1.
                    ax.plot( [x, x+dx], [y, y+dy], **style)


    return fig,ax,pos
