import numpy as np

# Dir where data lives
ddir = 'data/'

# Metadata
b_meta_fname = ddir + '16S rep set with tax + antifungal info.txt'

e_meta_fname = ddir +  '18S rep set with higher class tax + fungal phylum.csv'
e_meta_fname = ddir +  'fungal phyla 26 june 18S rep set with higher class tax.txt'


f_meta_fname = ddir +'ThoropaMapping_16S.txt'

# Abundances
b_abun_fname = ddir +'Bacteria_biome_table_boku63_nonchimeric_15nov_mc2_w_tax_no_pynast_failures.txt'
e_abun_fname = ddir +'Eukaryote_biome_table_18S_Filtermin20_29_jul_16_noVerts_no_Streptophyta.txt'




def GetMetadata(mode, remove_metazoans=True):
    """ Get dictionary of metadata for frogs, bacteria, or eukaryotes. """

    # Choose appropriate file and seperator char
    if mode=='frogs':
        meta_fname = f_meta_fname
        sep_char = '\t'
    elif mode=='eukaryotes':
        meta_fname = e_meta_fname
        sep_char = '\t'
    elif mode=='bacteria':
        meta_fname = b_meta_fname
        sep_char = '\t'
    else:
        print "Unknown metadata mode: " + str(mode)
        print "\t Options are frogs, bacteria, or eukaryotes"


    # Read in metadata from file
    with open(meta_fname, 'rU') as F:
        contents = [ [ x.strip() for x in line.strip().split(sep_char)]
                     for line in F ]
        # If some rows are short, pad them out so all are equal length
        ncols = max(map(len, contents))
        contents = [ row + [''] * (ncols-len(row)) for row in contents]

    # First row is labels, rest of rows are data
    meta = dict( zip(contents[0], np.array( contents[1:] ).T ) )




    # Special processing for bacteria:
    if mode=='bacteria':
        # Append B_ to start of OTU names
        meta['#OTU ID'] = [ 'B_' + x.strip()
                            for x in meta['#OTU ID'] ]


        # Get the phylum of each OTU
        phyla = []
        for x in meta['QIIME_consensus lineage']:

            # Full taxonomy
            tax = dict( [ [z.strip() for z in y.split('__') ]
                          for y in x.split(';') ] )
            # Use phylum if we have it
            if 'p' in tax:
                phyla.append( tax['p'] )
            # Otherwise, just use kingdom
            else:
                phyla.append( tax['k'])

        meta['phylum'] = np.array(phyla)



    # Special processing for eukaryotes
    if mode == 'eukaryotes':
        ####### For old format: 
        
        # Append E_ to start of OTU names
        meta['#OTU ID'] = [ 'E_' + x.strip()
                            for x in meta['OTU id'] ]
                            
                            
        meta['classification'] =  np.array(meta['Higher classification'])
        

            
        
        # Make sure non-fungi are blank in fungal pylum col
        meta['fungal phylum'] = meta['Fungus classification']
        
        for ii in range(len(meta['fungal phylum'] ) ):
            if not 'Fungi' in meta['Higher classification'][ii]:
                meta['fungal phylum'][ii] =''
                
            
        # Classification
        for ii,x in enumerate(meta['classification'] ):
            # Remove metazoa?
            if remove_metazoans and (
                'Metazoa' in meta['Higher classification'][ii]):
                x =''
            
            meta['classification'][ii] = x
  
    # Specialprocessing for frogs      
    if mode=='frogs':
        # Remove Gruta.da.Gaeca
        keep_inds = [ x for x, name in enumerate(meta['Sitename'])
            if not name == 'Gruta.da.Gaeca' ]
        
        for key in meta:
            meta[key] = np.array( [ meta[key][x] for x in keep_inds ] )
            
            
    # Return metadata dictionary
    return meta


def GetAbundances(f_meta, m_meta):
    """ Get bacterial or eukaryotic abundances by frog.
    Rows = frogs, cols = OTUs"""

    # If bacteria
    if 'B_' in m_meta['#OTU ID'][0]:
        mode = 'bacteria'
        prefix = 'B_'
        abun_fname = b_abun_fname

        # Translation for frog names in bacterial abundance file
        frog_name_dict = dict(
            zip( [ 'SLFT' + x.split('_')[-1] for x in f_meta['#SampleID'] ],
                 f_meta['Description']  
                 ) 
            )

    # Eukaryotes
    else:
        mode = 'eukaryotes'
        prefix = 'E_'
        abun_fname = e_abun_fname

    # Abundances
    M = []
    with open(abun_fname, 'r') as F:
        M = [ line.strip().split('\t') for line in F]

    # M[0] is comments
    # M[1] is sample names
    frog_names = M[1][1:-1]
    
    # Fix frog names if reading bacteria file
    if mode=='bacteria':
        new_frog_names = [ ]
        for x in frog_names:
            if x in frog_name_dict:
                new_frog_names.append( frog_name_dict[x])
            else: 
                new_frog_names.append(x)
        frog_names = new_frog_names
                

    # Dictionary of which column each frog is in
    frog_inds = dict(zip(frog_names, range(len(frog_names) ) ) )

    # Microbe names are in first column of M[2:]
    microbe_names = [ prefix + row[0] for row in M[2:] ]

    # Dictionary of which row each microbe is in
    microbe_inds = dict(zip(microbe_names, range(len(microbe_names) ) ) )

    # Abundances microbe & frog
    A = [ row[1:-1] for row in M[2:] ]


    # KLUGE: two frogs with no eukaryote swabs, give them columns of zeros
    if mode == 'eukaryotes':
        next_ind = len(frog_inds)
        for f in f_meta['Description']:
            if not f in frog_inds:
                frog_inds[f] = next_ind
                next_ind += 1
    
        new_A = np.zeros( (len(A), next_ind ) )
        new_A[:, :len(A[0]) ] = np.array(A)
        A = new_A


    # Now, reorder abundance matrix so it matches metadata files
    A = np.array(
        [ [ A[ microbe_inds[m] ][ frog_inds[f] ]
            for f in f_meta['Description'] ]
          for m in m_meta['#OTU ID']
          ], dtype=float )
    

    return A


def Read(fname):
    """ Read microbes on frogs from file to dict."""
    data = dict()
    with open(fname, 'r') as F:
        for line in F:
            line = line.strip().split(':')
            key = int(line[0])
            
            value=[]
            if not line[1]=='':
                value = map(int, line[1].split(', ') )
            
            data[key] = value
            
    return data
    
def Write(fname, data):
    """ Write adjacency dict to file"""
    with open(fname, 'w') as F:
        for key in data:
            line = str(key) + ':' + ', '.join(map(str, data[key])) + '\n'
            F.write(line)
    