
import numpy as np
import DataProcessing as dp
import PlotTools as pt



# Metadata
f_meta = dp.GetMetadata('frogs')
b_meta = dp.GetMetadata('bacteria')
e_meta = dp.GetMetadata('eukaryotes')


# Bacteria
b_vals = np.array( b_meta['phylum'] )
b_list = list(set( b_vals ))
b_list.sort()


# Eukaryotes: fungi and not
e_vals = e_meta['classification']

agg_e_vals = np.array(e_meta['classification'])

nf_list = list(set( 
    [ x for x in e_vals
        if not 'Fungi' == x and not x==''] ))
nf_list.sort()


agg_e_list =  ['Fungi'] + nf_list


f_vals = e_meta['fungal phylum']
f_vals[f_vals=='Other/unidentified'] = 'Other fungi'
f_list = list(set([ x for x in f_vals
    if not x=='']))
f_list.sort()

for ii in range(len(e_vals)):
    if  e_vals[ii] == 'Fungi':
        e_vals[ii] = f_vals[ii]

e_list = f_list + nf_list


# Fill out list of names, styles for nice graphs
styles, sizes, names = [], [], []
# Bacteria
for st in pt.GetFillStyles(b_list):
    names.append(st['label'])
    styles.append(st)
    sizes.append( sum( st['label'] == b_vals) ) 

# Eukaryotes
for st in pt.GetFillStyles( f_list, pastel=0.5 ):
    names.append(st['label'])
    styles.append(st)
    sizes.append( sum( st['label'] == e_vals) ) 
    
for st in pt.GetFillStyles( ['Fungi'] + nf_list ):
    names.append(st['label'])
    styles.append(st)
    sizes.append( sum( st['label'] == e_vals) ) 

# Dict for finding index of each name
name_inds = dict(zip(names, range(len(names)) ))

    
    

# Antifungal or not
af_vals =  b_meta['Predicted_effects_on_fungi']
af_vals[af_vals==''] = 'unknown'
af_list = [ x for x in list(set(af_vals)) ]
af_list.sort()
af_inds = dict(zip(af_list, range(len(af_list))))

    
# MHC frog genotype
gt_vals = f_meta['gt']
gt_list = list(set([x for x in gt_vals if not x=='' ]))
gt_list.sort()
gt_inds = dict(zip(gt_list, range(len(gt_list))))

    
# Sample sites, by type and name
# List of unique sites, sorted by type and name
site_list = list(set(
        [ f_meta['Sitetype'][ii] 
          + '\t'+ f_meta['Sitename'][ii]
          for ii in range(len( f_meta['Sitetype'] ))
          if not f_meta['Sitename'][ii] =='' ] ) )
site_list.sort()
# Separate type and name lists
type_by_site = [ x.split('\t')[0] for x in site_list ]
site_list = [ x.split('\t')[-1] for x in site_list ]

site_type_list = list(set(type_by_site))
site_type_list.sort()

# Index of each site in the list
site_inds = dict(zip(site_list, range(len(site_list) ) ) )

# Frog site names
site_vals = f_meta['Sitename']
site_types = f_meta['Sitetype']


    
#### Read in observed reads of bacteria, eukaryotes
b_abundance = dp.GetAbundances(f_meta, b_meta)
e_abundance = dp.GetAbundances(f_meta, e_meta)