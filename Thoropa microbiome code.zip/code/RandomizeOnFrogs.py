from Setup import *
import RandomizationTools as rt

out_dir = 'out/rewire/'
num_shuffles=1000
sweeps_per_shuffle=1000

# Both genotype and 
both_vals = [ '' ] * len(site_types)
for ii in range(len(site_types)):
    x = site_types[ii]
    y = gt_vals[ii]
    if not (x=='' or y ==''):
    
       both_vals[ii] = x + ', ' + y
       
both_list = [ x for x in list(set(both_vals))
    if not x=='']
both_list.sort()

for mode, A in [
    [ 'bacteria', np.array(b_abundance).T],
    [ 'eukaryote', np.array(e_abundance).T] ]:
    
    
    # Make into a dictionary of microbes by frogs
    obs = dict()
    for ii in range(len(A)):
        obs[ii] = [jj for jj in range(len(A[ii])) if A[ii,jj] > 0]
    
    dp.Write(out_dir + mode + '-observed', obs)
    
    # Shuffles
    for rep in range(num_shuffles):
        
        shuffled = dict()
        # Shuffle frogs within each category
        for bval in both_list:
            sh = dict()
            for ii, v in enumerate(both_vals):
                if v==bval:
                    sh[ii] = list(obs[ii])
                    
            # Now shuffle
            if len(sh.keys()) > 0:
                sh = rt.RandomizeDirected(sh, sweeps=sweeps_per_shuffle)
            
            for key in sh:
                shuffled[key] = sh[key]
                
        # Now write it to file
        dp.Write(out_dir + mode + '-shuffle-' + str(rep), shuffled)