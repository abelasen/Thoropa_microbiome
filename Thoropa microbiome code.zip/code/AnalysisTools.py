
import math
import numpy as np

def GetZScore(counts, sh_counts):
    """ Get zscores of observed values relative to shuffled"""
    Z = np.zeros(counts.shape)
    for ri, row in enumerate(counts):
        for ci, val in enumerate(row):
            mean = np.mean(sh_counts[:,ri,ci])
            var = np.var(sh_counts[:,ri,ci]-mean)
            
            Z[ri,ci] = (counts[ri,ci] - mean) / var**0.5
    
    return Z

def GetSignedPVals(counts, sh_counts, vmin=-3, vmax=3):
    """ Get pvalues + sign indicating if observed value
    is high (+), low (-) compared to shuffled."""
    
    
    # Over/under
    M = np.zeros(counts.shape)
    for ri, row in enumerate(counts):
        for ci, val in enumerate(row):
            # How often is shuffled over,under observed value
            
            
            over = np.mean(val > sh_counts[:,ri,ci])
            under = np.mean(val < sh_counts[:,ri,ci])
            tie = 1.0-over-under
            
                
            # If usually over, display that p
            c = 0
            if over > max(under, tie):
                c = -math.log10( max(1.-over, 10**-vmax ) )
            # IF usually under, display that
            elif under > max(over, tie): 
                c = math.log10( max(1. - under, 10**-abs(vmin)) )
            M[ri,ci] =  c
            
    return M
    
    
def GetCoOccurrence(x_present, x_vals, x_list, y_present, y_vals, y_list):
    """ From a dict of microbes on frogs, count co-occurrences of categories."""
    xN, yN = len(x_list), len(y_list)
    # Co-occurrences x to x, y to y, x to y
    xx_co = np.zeros( (xN,xN) )
    yy_co = np.zeros( (yN, yN) )
    xy_co = np.zeros( (xN, yN) )
    
    x_inds = dict(zip(x_list, range(xN) ))
    y_inds = dict(zip(y_list, range(yN) ))
    
    frogs = [x for x in x_present if x in y_present]
    for frog in frogs:
        xs = x_present[frog]
        ys = y_present[frog]
    
    
        # For each pair of xs
        for xi, x in enumerate(xs):
            for x2 in xs[:xi]:
                if x_vals[x] in x_inds and x_vals[x2] in x_inds:
                    xx_co[ x_inds[x_vals[x]], 
                            x_inds[x_vals[x2]] ] += 1
                    xx_co[ x_inds[x_vals[x2]], 
                        x_inds[x_vals[x]] ] += 1
                    
        # For each pair of ys
        for yi, y in enumerate(ys):
            for y2 in ys[:yi]:
                if y_vals[y] in y_inds and y_vals[y2] in y_inds:
                    yy_co[ y_inds[y_vals[y]], 
                        y_inds[y_vals[y2]] ] += 1
                    yy_co[  y_inds[y_vals[y2]], 
                        y_inds[y_vals[y]] ] += 1
                
    
        # For each xy pair
        # For each pair of xs
        for x in xs:
            for y in ys:
                if x_vals[x] in x_inds and y_vals[y] in y_inds:
                    xy_co[ 
                        x_inds[x_vals[x]], 
                        y_inds[y_vals[y]] ] += 1
                        
    return xx_co, yy_co, xy_co