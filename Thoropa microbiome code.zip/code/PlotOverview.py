
from Setup import *


plot_dir = 'plots/overview/'
nbins=20 # number of bins to use in the plots

    
######## Plot occurrence on % of frogs

for microbe_mode, aux, A, m_list, m_vals, do_inset in [
    ['bacterial OTUs', '', b_abundance, b_list, b_vals, False],
    ['eukaryote OTUs', '',  e_abundance, e_list, e_vals, True],
    ['eukaryote OTUs', ' aggregating fungi', e_abundance,   
        agg_e_list, agg_e_vals, True]
    ]:
    inds = dict(zip(m_list, range(len(m_list)) ))
    
    # percent of frogs where each particular microbe is present
    fracs = np.mean(A>0, axis=1)
     
    # Prevalence of each type in each bin
    prev = np.zeros( (len(m_list), nbins) )
    for v, f in zip(m_vals, fracs):
        # Pick bin for prevalence value
        xi = min( nbins-1, int(f * nbins) )
        # Increment count if not an uncatagorized type
        if not v == '':
            prev[inds[v], xi] += 1.
    prev = prev / float(len(m_vals)) * 100.
            
    # Styles for filling
    m_styles = [ styles[ name_inds[m] ] for m in m_list ]
        

    # Get a figure and axes to draw on
    fig,ax = pt.FigAndAx(axRect=(0.1,0.1, 0.85, 0.85) )
    # Inset for zooming on tail
    if do_inset:
        inset = fig.add_axes( (0.35, 0.35, 0.55, 0.55) )
    
    # Label axes
    ax.set_xlabel('% of frogs where present', **pt.labelfont)
    ax.set_ylabel('% of ' + microbe_mode, 
                    **pt.labelfont)
    
    
    if do_inset:
        inset.set_xlabel('% of frogs', **pt.labelfont)
        inset.set_ylabel('% of ' + microbe_mode, 
                    **pt.labelfont)
        inset.set_title('Zoomed in on tail')
    
    
    # Fill bars
    # xs for filling stacked bars for each bin
    xs = np.array( [ [x,x] for x in np.linspace(0,100,nbins+1) ] 
            ).ravel()[1:-1]
    # Ticks on the x axis - one for each site
    
    # For each microbe type, draw it on
    handles = [] # For legend
    floor = np.zeros(xs.shape)
    for st, ys in zip(m_styles, prev)[::-1]:
        # Reshape to have rectangle blocks
        block = np.zeros(floor.shape)
        block[np.arange(0, len(xs),2)] = ys
        block[np.arange(1, len(xs),2)] = ys
        
        # Fill
        cs=ax.fill_between(xs,floor, floor+block, **st)
        
        if do_inset:
            inset.fill_between(xs, floor, floor+block,
                            **st )
        handles.append(cs)
        
        # Move floor up
        floor += block
        
    # Reverse handle order to match microbe list
    handles = handles[::-1]
    
    # Set axis limits
    ax.set_xlim(0,100)
    ymax = int(max(floor) / 5 ) * 5 + 5
    ax.set_ylim( 0, ymax)
    
    
    xmin=20
    inset_xticks = range(20,100,20)
    if 'eukaryote' in microbe_mode:
        xmin = 5
        inset_xticks = [5] + range(20,100,20)
    
    
    if do_inset:
        inset.set_xlim(xmin,100)
        ymax = int(max(floor[xs>xmin]) / 5 ) * 5 + 5
        inset.set_ylim( 0, ymax)
    
        inset.set_xticks(inset_xticks)
    
    # Make a nice legend
    pt.Legend(fig=fig, labels=m_list, handles=handles,
        bbox_to_anchor=(1,0,0.3,1) 
        )

    # Save and close figure
    pt.SaveAndClose(fig, plot_dir + microbe_mode + aux + '-presence-on-frogs')

                     
                      
# By site plots of % reads, % OTUs present
for microbe_mode, aux, M, m_list, m_vals in [
    ['bacterial','', b_abundance, b_list, b_vals],
    ['eukaryote', '', e_abundance, e_list, e_vals],
    ['eukaryote', ' aggregating fungi', e_abundance, agg_e_list, agg_e_vals]
    ]:
    
    
    inds = dict(zip(m_list, range(len(m_list)) ))
    # Styles for filling
    m_styles = [ styles[ name_inds[m] ] for m in m_list ]
    
    
    # Count of reads, presence of each type of microbe
    # at each site
    reads = np.zeros( (len(m_list), len(site_list)) )
        
    # Go through each microbe on each frog
    for m, microbe_row in zip(m_vals, M):
        if m in inds:
            #Index of microbe
            mi = inds[m]
                
            for site, r in zip(site_vals, microbe_row):
                # Index of site
                si = site_inds[site]
                    
                # Count reads
                reads[mi, si] += r   
        
    # Now for each site turn into %s
    for si in range(len(site_list)):
        reads[:, si] = reads[:, si]  *100./ sum(reads[:, si]) 
                
        
        
    # Get a figure and axes to draw on
    fig,ax = pt.FigAndAx(axRect=(0.1,0.1, 0.85, 0.85) )
        
    ax.set_xticks(np.arange(0.5, len(site_list) ) )
    ax.set_xticklabels(site_list, rotation='vertical', **pt.labelfont)
    for ti, tick in enumerate(ax.get_xticklabels()):
            if type_by_site[ti] == 'Island':
                tick.set_weight('bold')
        
    ax.set_ylabel( '% of ' + microbe_mode + ' reads found at site',**pt.labelfont)
            
            
    # Fill bars:
    # xs for filling stacked bars for each bin
    xs = np.array( [ [x,x] for x in range( len(site_list) +1 ) ] 
            ).ravel()[1:-1]
    
    # For each microbe type, draw it on
    handles = [] # For legend
    floor = np.zeros(xs.shape)
    for st, ys in zip(m_styles, reads)[::-1]:
        #print ys, st['label']
        # Reshape to have rectangle blocks
        block = np.zeros(floor.shape)
        block[np.arange(0, len(xs), 2) ] = ys
        block[np.arange(1, len(xs), 2) ] = ys
        
        # Fill
        cs = ax.fill_between(xs, floor, floor+block,
                        **st )
        handles.append(cs)
        
        # Move floor up
        floor += block
    handles = handles[::-1]
    
    # Set axis limits
    ax.set_xlim( 0,len(site_list) )
    ax.set_ylim( 0, 100)

        
    # Make a nice legend
    pt.Legend(fig=fig, labels=m_list, handles=handles,
        bbox_to_anchor=(1,0,0.3,1) 
        )
        
    # Save and close figure
    pt.SaveAndClose(fig, plot_dir + microbe_mode 
            + '-reads-by-site')
        
        
    # Next: OTUs present at each site
    present = np.zeros( (len(m_vals), len(site_list) ) )
    for ri, row in enumerate(M):
        for site, v in zip(site_vals, row):
            if v > 0:
                present[ ri, site_inds[site] ] = 1.
                
    # Collapse into types
    counts = np.zeros( (len(m_list), len(site_list) ) )
    for m, row in zip(m_vals, present):
        if not m=='':
            mi = inds[m]
            counts[mi] += row
     
    # Now for each site turn into %s
    for si in range(len(site_list)):
        counts[:, si] = counts[:, si]  *100./ sum(counts[:, si]) 
                
        
        
    # Get a figure and axes to draw on
    fig,ax = pt.FigAndAx(axRect=(0.1,0.1, 0.85, 0.85) )
        
    ax.set_xticks(np.arange(0.5, len(site_list) ) )
    ax.set_xticklabels(site_list, rotation='vertical', **pt.labelfont)
    for ti, tick in enumerate(ax.get_xticklabels()):
            if type_by_site[ti] == 'Island':
                tick.set_weight('bold')
        
    ax.set_ylabel( '% of ' + microbe_mode + ' OTUs found at site',
        **pt.labelfont)
            
            
    # Fill bars:
    # xs for filling stacked bars for each bin
    xs = np.array( [ [x,x] for x in range( len(site_list) +1 ) ] 
            ).ravel()[1:-1]
    
    # For each microbe type, draw it on
    handles = [] # For legend
    floor = np.zeros(xs.shape)
    for st, ys in zip(m_styles, counts)[::-1]:
        #print ys, st['label']
        # Reshape to have rectangle blocks
        block = np.zeros(floor.shape)
        block[np.arange(0, len(xs), 2) ] = ys
        block[np.arange(1, len(xs), 2) ] = ys
        
        # Fill
        cs = ax.fill_between(xs, floor, floor+block,
                        **st )
        handles.append(cs)
        
        # Move floor up
        floor += block
    handles = handles[::-1]
        
    
    # Set axis limits
    ax.set_xlim( 0,len(site_list) )
    ax.set_ylim( 0, 100)

    
        
    # Make a nice legend
    pt.Legend(fig=fig, labels=m_list, handles=handles,
        bbox_to_anchor=(1,0,0.3,1) 
        )
    # Save and close figure
    pt.SaveAndClose(fig, plot_dir + microbe_mode +aux
            + '-OTUs-by-site')
        