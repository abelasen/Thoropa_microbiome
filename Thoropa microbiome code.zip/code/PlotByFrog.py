from Setup import *
import AnalysisTools as at


plot_dir = 'plots/by-frog/'

num_shuffles = 1000
vmin,vmax=-3,3

both_vals = [ '' ] * len(site_types)
for ii in range(len(site_types)):
    x = site_types[ii]
    y = gt_vals[ii]
    if not (x=='' or y ==''):
    
       both_vals[ii] = x + ', ' + y
       
both_list = [ x for x in list(set(both_vals))
    if not x=='']
both_list.sort()

none_vals  = np.zeros(gt_vals.shape)

for microbe_mode, aux, A, m_list, m_vals in [
    ['Bacterial OTUs','', b_abundance, b_list, b_vals],
    ['Eukaryote OTUs', '', e_abundance, e_list, e_vals],
    ['Eukaryote OTUs', ' aggregating fungi', e_abundance, agg_e_list, agg_e_vals]
    ]:
    
    
    for frog_mode, f_list, f_vals, c_vals in [
        [ 'Site type', site_type_list, site_types, 
            gt_vals],
        [ 'Frog genotype', gt_list, gt_vals, 
            site_types],
        [ 'Site type and genotype', both_list, both_vals, 
            none_vals ] ]:
    
        m_inds = dict(zip(m_list, range(len(m_list))))
        f_inds = dict(zip(f_list, range(len(f_list))))
        
        # Observed
        obs = np.zeros( ( len(m_list), len(f_list) ) )
        obs_lists = dict() # List of pairs observed for each control
        for m, row in zip(m_vals, A):
            for ind, r in enumerate(row):
                f = f_vals[ind]
                control = c_vals[ind]
                
                if r > 0 and not f=='' and not m=='':
                    fi = f_inds[f]
                    mi = m_inds[m]
                    obs[mi, fi] += 1.
                    
                    # Add to list of pairs under control condition
                    if not control in obs_lists:
                        obs_lists[control] = []
                    obs_lists[control] = obs_lists[control] +  [ [mi,fi] ]
        
        
        
                
        # Shuffled
        shuffled = np.zeros( (num_shuffles, len(m_list), len(f_list) ) )
        
        for rep in range(num_shuffles):
            # Shuffle each subset of pairs
            rows = []
            cols = []
            for key in obs_lists:
                edges = np.array(obs_lists[key])
                rows += list(edges[:,0])
                cc = list( edges[:,1] )
                np.random.shuffle(cc)
                cols += cc    
            # Add up new pair counts
            for ri,ci in zip(rows, cols):
                shuffled[rep, ri, ci] += 1
            
            
            
        # Get p-values 
        M = at.GetSignedPVals(obs, shuffled, vmin=vmin, vmax=vmax)
        
        
        # Get a figure and axes to draw on
        fig,ax = pt.FigAndAx()
        ax.tick_params(direction='out')
        
        # Setup x axis
        xticklabels = f_list
        ax.set_xlabel(frog_mode, **pt.labelfont )
    
    
        # Setup y axis
        yticklabels = m_list[::-1]
        ax.set_ylabel(microbe_mode, **pt.labelfont )
        
        
        # Ticks
        midpoints = list( np.arange(0.5, 
            max( len(xticklabels), len(yticklabels) ), 1 ) )
        
        
        # xticks
        ax.set_xticks( midpoints )
        ax.set_xticklabels( xticklabels,  
                        rotation='vertical',
                        **pt.labelfont )
    
        ax.set_xlim( 0, len(xticklabels) )
        
        # yticks
        ax.set_yticks( midpoints  )
        ax.set_yticklabels( yticklabels,  
                            **pt.labelfont )
        ax.set_ylim( 0, len(yticklabels) )
        
        # Shade co-occurrence of each microbe, 
        # with microbes sorted into categories
        cb = pt.MatrixAndColorbar(ax, M[::-1], 
            vmin=vmin, vmax=vmax, cmap='bwr')
            
            
        # Annotate with nice dots for significance
        print M.shape
        for yi, row in enumerate(M[::-1]):
            for xi, p in enumerate(row):
                pi = None
                next_pi = 0
                while next_pi < len(pt.p_threshold):
                    if abs(p) > pt.p_threshold[next_pi]:
                        pi = next_pi
                    next_pi = next_pi + 1
                
                if pi is not None:
                    ax.plot(midpoints[xi], midpoints[yi], **pt.p_styles[pi])
                    
    
        cb.set_label('\n\n\n Present < expected       ' 
                    + '      Present >  expected\n'
                    + '($p$-value using ' + str(num_shuffles) + ' randomizations)',
                    va='center',
                    **pt.labelfont
                    )
    
                                                        
        cb.ax.tick_params( **pt.cbtickfont) 
        # Save and close figure
        pt.SaveAndClose(fig,  plot_dir + microbe_mode + aux + '-' + frog_mode)