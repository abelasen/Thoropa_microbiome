from Setup import *
import AnalysisTools as at


rewire_dir = 'out/rewire/'
plot_dir = 'plots/co-occurrence/'
num_shuffles = 1000
vmin, vmax = -3,3
edge_threshold = 3

# Setup markers for network plot
for name, st in zip(names, styles):
    st['label'] = '\n' + st['label'] + '\n'
    
    # Triangle for bacteria
    if name in b_list:
        st['marker'] = '^'
    elif name in f_list:
        st['marker'] = 's'
    else:
        st['marker'] = 'o'
        
non_agg_names = [x for x in names if not x=='Fungi']

# Read in presence/absence dict
b_obs = dp.Read('out/rewire/' + 'bacteria-observed')
e_obs = dp.Read('out/rewire/'  + 'eukaryote-observed')
bN, eN = len(b_list), len(e_list)

# Convert to co-occurrence
bb_obs, ee_obs, be_obs = at.GetCoOccurrence(
    b_obs, b_vals, b_list, e_obs, e_vals, e_list)


bb_sh, ee_sh, be_sh = [], [], []
# Repeat for each shuffled replicate
for rep in range(num_shuffles):
    print rep
    # Read in presence dict
    b_sh = dp.Read(rewire_dir + 'bacteria-shuffle-' + str(rep) ) 
    e_sh = dp.Read(rewire_dir + 'eukaryote-shuffle-' + str(rep) ) 
        
    # Get three co-occurrences
    bb,ee,be = at.GetCoOccurrence(
        b_sh, b_vals, b_list, e_sh, e_vals, e_list)
    # Append to list
    bb_sh.append(bb) 
    ee_sh.append(ee) 
    be_sh.append(be)
    

    
# Convert to Pval matrices
bb_M = at.GetSignedPVals(bb_obs, np.array( bb_sh) )
ee_M = at.GetSignedPVals(ee_obs, np.array(ee_sh) )
be_M = at.GetSignedPVals(be_obs, np.array(be_sh) )



bb_Z = at.GetZScore(bb_obs, np.array( bb_sh) )
ee_Z = at.GetZScore(ee_obs, np.array(ee_sh) )
be_Z = at.GetZScore(be_obs, np.array(be_sh) )

# Fill into a matrix containing all
full_M = np.zeros( (bN+eN, bN+eN) )
full_M[:bN, :bN] = bb_M
full_M[bN:, bN:] = ee_M
full_M[:bN, bN:] = be_M
full_M[bN:, :bN] = be_M.T



# Fill into a matrix containing all
full_Z= np.zeros( (bN+eN, bN+eN) )
full_Z[:bN, :bN] = bb_Z
full_Z[bN:, bN:] = ee_Z
full_Z[:bN, bN:] = be_Z
full_Z[bN:, :bN] = be_Z.T

for  M, Z, row_label, row_list, col_label, col_list in [
    [bb_M, bb_Z, 'Bacterial OTU', b_list, 'Bacterial OTU',b_list],
    [ee_M, ee_Z, 'Eukaryote OTU', e_list, 'Eukaryote OTU',e_list],
    [be_M.T, be_Z.T, 'Eukaryote OTU',e_list, 'Bacterial OTU', b_list],
    [full_M, full_Z, 'OTU', non_agg_names, 'OTU', non_agg_names] ]:
        
        
    # Heat plot
        # Get a figure and axes to draw on
        fig,ax = pt.FigAndAx()
        ax.tick_params(direction='out')
        
        # Setup x axis
        xticklabels = col_list
        ax.set_xlabel(col_label, **pt.labelfont )
    
    
        # Setup y axis
        yticklabels = row_list[::-1]
        ax.set_ylabel(row_label, **pt.labelfont )
        
        
        # Ticks
        midpoints = list( np.arange(0.5, 
            max( len(xticklabels), len(yticklabels) ), 1 ) )
        
        
        # xticks
        ax.set_xticks( midpoints )
        ax.set_xticklabels( xticklabels,  
                        rotation='vertical',
                        **pt.labelfont )
    
        ax.set_xlim( 0, len(xticklabels) )
        
        # yticks
        ax.set_yticks( midpoints  )
        ax.set_yticklabels( yticklabels,  
                            **pt.labelfont )
        ax.set_ylim( 0, len(yticklabels) )
        
        # Shade co-occurrence of each microbe, 
        # with microbes sorted into categories
        cb = pt.MatrixAndColorbar(ax, M[::-1], 
            vmin=vmin, vmax=vmax, cmap='bwr')
            
            
        # Annotate with nice dots for significance
        print M.shape
        for yi, row in enumerate(M[::-1]):
            for xi, p in enumerate(row):
                pi = None
                next_pi = 0
                while next_pi < len(pt.p_threshold):
                    if abs(p) > pt.p_threshold[next_pi]:
                        pi = next_pi
                    next_pi = next_pi + 1
                
                if pi is not None:
                    ax.plot(midpoints[xi], midpoints[yi], **pt.p_styles[pi])
                    
    
        cb.set_label('\n\n\n Co-occurrences < expected       ' 
                    + '      Co-occurrences >  expected\n'
                    + '($p$-value using ' + str(num_shuffles) + ' randomizations)',
                    va='center',
                    **pt.labelfont
                    )
    
                                                        
        cb.ax.tick_params( **pt.cbtickfont) 
        # Save and close figure
        pt.SaveAndClose(fig,  plot_dir + col_label + '-' + row_label)
        
        
        # Network for appropriate combinations
        if row_label == col_label:
            # WEights for network
            W = np.array(Z)
            W[W < edge_threshold] = 0
            fig,ax = pt.FigAndAx()
        
        
            style_list = [styles[ name_inds[x] ] for x in col_list]
            size_list = [sizes[ name_inds[x] ] for x in col_list]
        
        
            # Get a figure and axes to draw on
            fig, ax, pos = pt.PrettyDraw(
                style_list, size_list, W
                )
                
            pt.Legend( ncol=(1 + len(W)/12) )
        
            pt.SaveAndClose(fig,  
                plot_dir + col_label + '-' + row_label + '-network')
    
    
    
    
    # Network plot