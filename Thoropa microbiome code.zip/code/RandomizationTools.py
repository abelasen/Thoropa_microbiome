

import numpy as np

def RandInt(x):
    return int(x*np.random.random())

def RandomizeDirected(data, sweeps=1000, in_mode='dict', out_mode='dict'):
    """ Given directed adjacency data, get a randomized version
        with all same in/out degrees. format options are:
            dict
            matrix
            list
            
            """
        
    # populate edge list and dictionary       
    if in_mode == 'matrix':
        E_dict = dict()
        E_list = []
        for ii,row in enumerate(data):
            ii_list = []
            for jj, value in enumerate(row):
                if value:
                    ii_list.append(jj)
                    E_list.append( [ii,jj] )
            E_dict[ii] = list(ii_list)
            
    elif in_mode == 'list':
        E_list = list(data)
        E_dict = dict()
        for u,v in E_list:
            u_list = []
            if u in E_dict:
                u_list = list(E_dict[u])
            E_dict[u] = u_list + [v]

    elif in_mode=='dict':
        E_dict = dict(data)
        E_list = []
        for u in E_dict:
            for v in E_dict[u]:
                E_list.append( [u,v] )
    
    # Total edges
    m = len(E_list)
    
    moves  = 0
    # Do moves
    for t in range(sweeps * m):
        # Pick two edges uniformly at random
        ii = RandInt(m)
        jj = RandInt(m-1)
        if jj >= ii:
            jj+=1
            
        # Edge ends
        fromA, toA = E_list[ii]
        fromB, toB = E_list[jj]
        
        # Check if edges are allowed to swap:
        # neither end is just swapping same nodes
        if ( not ( fromA==fromB or toA==toB)
            and # Neither new edge already exists
             not (toA in E_dict[fromB] or toB in E_dict[fromA] )
             ):
            
            moves += 1
            
            # Update the edge list
            E_list[ii] = [fromB, toA]
            E_list[jj] = [fromA, toB]
            # Update the edge dict:
            # Replace outgoing edge from A
            A_list = list( E_dict[fromA] )
            A_list[ A_list.index(toA) ] = toB
            E_dict[fromA] = A_list
            # Replace outgoing list from B
            B_list = list( E_dict[fromB] )
            B_list[ B_list.index(toB) ] = toA
            E_dict[fromB] = B_list
            
    print m, moves, moves/m
    if out_mode=='matrix':
        # Populate new adjacency matric
	A = np.zeros( data.shape )
        for u,v in E_list:
            A[u,v] = 1
        
        return A
        
    elif out_mode=='list':
        return E_list
        
    elif out_mode=='dict':
        return E_dict
    